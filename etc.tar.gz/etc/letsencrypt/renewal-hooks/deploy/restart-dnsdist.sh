#!/bin/sh
systemctl restart dnsdist
